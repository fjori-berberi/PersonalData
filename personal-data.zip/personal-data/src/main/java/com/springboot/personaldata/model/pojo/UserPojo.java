package com.springboot.personaldata.model.pojo;

public class UserPojo {
}
