package com.springboot.personaldata;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
